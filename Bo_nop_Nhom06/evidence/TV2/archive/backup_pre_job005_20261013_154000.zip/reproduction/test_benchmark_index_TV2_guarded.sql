﻿-- ============================================================================
-- TV2 BENCHMARK GUARDED REPRODUCTION SCRIPT (OFFLINE GENERATED)
-- Derived from: test_benchmark_index_TV2.sql
-- Source SHA-256: ABA2B984309326A4947241CFC669AD0A08492101EFA6872493F79C02036A347E
-- Target Database: PRJ_Fix_QA_20261013_001534_ae185d81 (Strict Guarded)
-- Execution Protocol: sqlcmd -b -V16 -S localhost -d PRJ_Fix_QA_20261013_001534_ae185d81 -E -C -i ...
-- DO NOT EXECUTE IN CURRENT WORKFLOW — REPRODUCTION / AUDIT ARTIFACT ONLY
-- ============================================================================

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- PROJECT: Quáº£n LÃ½ NhÃ¢n Sá»± vÃ  Tiá»n LÆ°Æ¡ng (DBMS330284) - NhÃ³m 06
-- Há»ŒC PHáº¦N: Há»‡ Quáº£n Trá»‹ CÆ¡ Sá»Ÿ Dá»¯ Liá»‡u
-- PHÃ‚N Há»†: QUáº¢N LÃ CHáº¤M CÃ”NG (ATTENDANCE) - TUáº¦N 3
-- TÃC GIáº¢: TV2 - Pháº¡m Minh QuÃ¢n (MSSV: 24110311)
-- CHUYÃŠN Äá»€: ÄO LÆ¯á»œNG VÃ€ ÄÃNH GIÃ HIá»†U NÄ‚NG NON-CLUSTERED COVERING INDEX
-- Äá»I TÆ¯á»¢NG Sá»ž Há»®U: IX_CHAMCONG_MaNV_Ngay TRÃŠN Báº¢NG CHAMCONG
-- ============================================================================

-- Keep the database selected by the caller.

PRINT N'============================================================================';
PRINT N'  Báº®T Äáº¦U CHÆ¯Æ NG TRÃŒNH BENCHMARK INDEX: IX_CHAMCONG_MaNV_Ngay (TV2)';
PRINT N'============================================================================';
PRINT N'LÆ¯U Ã Ká»¸ THUáº¬T:';
PRINT N'  - Báº£ng sáº£n xuáº¥t dbo.CHAMCONG Ä‘Ã£ cÃ³ rÃ ng buá»™c UQ_CHAMCONG_MaNV_Ngay trÃªn (MaNV, NgayChamCong).';
PRINT N'  - RÃ ng buá»™c UNIQUE nÃ y Ä‘Ã£ tá»± Ä‘á»™ng táº¡o má»™t Non-clustered Index tÃ¬m kiáº¿m theo khÃ³a.';
PRINT N'  - Do Ä‘Ã³, so sÃ¡nh Table Scan (bá» index) lÃ  phi thá»±c táº¿ vÃ  gÃ¢y hiá»ƒu nháº§m.';
PRINT N'  - GiÃ¡ trá»‹ cá»‘t lÃµi cá»§a IX_CHAMCONG_MaNV_Ngay lÃ  COVERING INDEX vá»›i má»‡nh Ä‘á» INCLUDE';
PRINT N'    (GioVao, GioRa, TrangThai), giÃºp loáº¡i bá» hoÃ n toÃ n Key Lookup (Clustered Lookup)';
PRINT N'    khi tra cá»©u chi tiáº¿t cÃ´ng vÃ  tá»•ng há»£p thÃ¡ng (vw_TongHopChamCongThang).';
PRINT N'  - Ká»‹ch báº£n sá»­ dá»¥ng báº£ng táº¡m cá»¥c bá»™ session-local (#CHAMCONG_BENCHMARK) Ä‘á»ƒ cÃ¡ch ly 100%';
PRINT N'    an toÃ n, tuyá»‡t Ä‘á»‘i khÃ´ng táº¡o/xÃ³a báº£ng trong schema dbo vÃ  khÃ´ng can thiá»‡p cache há»‡ thá»‘ng.';
PRINT N'============================================================================';

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 1: Táº O Báº¢NG Táº M Cá»¤C Bá»˜ Äá»˜C Láº¬P Äá»‚ BENCHMARK AN TOÃ€N (ISOLATION)
-- Sá»­ dá»¥ng #CHAMCONG_BENCHMARK trong tempdb, hoÃ n toÃ n khÃ´ng Ä‘á»¥ng cháº¡m dbo.CHAMCONG
-- ============================================================================
IF OBJECT_ID('tempdb..#CHAMCONG_BENCHMARK') IS NOT NULL
    DROP TABLE #CHAMCONG_BENCHMARK;

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

CREATE TABLE #CHAMCONG_BENCHMARK (
    MaChamCong    INT           IDENTITY(1,1) NOT NULL,
    MaNV          INT           NOT NULL,
    NgayChamCong  DATE          NOT NULL,
    GioVao        TIME(0)       NOT NULL,
    GioRa         TIME(0)       NULL,
    TrangThai     NVARCHAR(20)  NOT NULL CONSTRAINT DF_Bench_TrangThai DEFAULT N'CO_MAT',
    GhiChu        NVARCHAR(255) NULL,

    -- KhÃ³a chÃ­nh Clustered tÆ°Æ¡ng tá»± dbo.CHAMCONG
    CONSTRAINT PK_Bench_ChamCong PRIMARY KEY CLUSTERED (MaChamCong),

    -- RÃ ng buá»™c duy nháº¥t tÆ°Æ¡ng tá»± UQ_CHAMCONG_MaNV_Ngay, cung cáº¥p chá»‰ má»¥c cÆ¡ sá»Ÿ trÃªn (MaNV, NgayChamCong)
    CONSTRAINT UQ_Bench_MaNV_Ngay UNIQUE NONCLUSTERED (MaNV, NgayChamCong)
);

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 2: SINH 30.000 Báº¢N GHI Dá»® LIá»†U Äá»ŠNH CHáº¾ (DETERMINISTIC DATA)
-- 100 nhÃ¢n viÃªn (MaNV 1..100) x 300 ngÃ y phÃ¢n biá»‡t -> Äáº£m báº£o 100% khÃ´ng trÃ¹ng khÃ³a
-- ============================================================================
PRINT N'Äang náº¡p 30.000 báº£n ghi cháº¥m cÃ´ng thá»­ nghiá»‡m vÃ o báº£ng táº¡m #CHAMCONG_BENCHMARK...';
SET NOCOUNT ON;

;WITH Numbers AS (
    SELECT TOP (30000) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS N
    FROM sys.all_columns a CROSS JOIN sys.all_columns b
)
INSERT INTO #CHAMCONG_BENCHMARK (MaNV, NgayChamCong, GioVao, GioRa, TrangThai, GhiChu)
SELECT
    ((N - 1) % 100) + 1 AS MaNV,
    DATEADD(DAY, -((N - 1) / 100), '2026-09-30') AS NgayChamCong,
    CASE (N % 10)
        WHEN 0 THEN CAST('08:20:00' AS TIME(0))
        WHEN 1 THEN CAST('08:35:00' AS TIME(0))
        ELSE CAST('07:55:00' AS TIME(0))
    END AS GioVao,
    CASE (N % 12)
        WHEN 0 THEN CAST('16:30:00' AS TIME(0))
        WHEN 1 THEN CAST('16:45:00' AS TIME(0))
        ELSE CAST('17:15:00' AS TIME(0))
    END AS GioRa,
    CASE
        WHEN (N % 20) = 0 THEN N'VANG'
        WHEN (N % 10) IN (0, 1) THEN N'DI_TRE'
        WHEN (N % 12) IN (0, 1) THEN N'VE_SOM'
        ELSE N'CO_MAT'
    END AS TrangThai,
    N'Dá»¯ liá»‡u sinh tá»± Ä‘á»™ng phá»¥c vá»¥ Benchmark Index TV2' AS GhiChu
FROM Numbers;

PRINT N'Náº¡p dá»¯ liá»‡u hoÃ n táº¥t: ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + N' báº£n ghi.';

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 3: ÄO LÆ¯á»œNG TRÆ¯á»šC KHI CÃ“ COVERING INDEX (BEFORE COVERING INDEX)
-- TÃ¬nh tráº¡ng: Chá»‰ cÃ³ UQ_Bench_MaNV_Ngay (Non-clustered Index Seek)
-- nhÆ°ng thiáº¿u cá»™t INCLUDE -> Pháº£i thá»±c hiá»‡n Key Lookup (Clustered) tá»«ng dÃ²ng.
-- HÆ°á»›ng dáº«n: Báº­t "Include Actual Execution Plan" (Ctrl + M) trong SSMS Ä‘á»ƒ quan sÃ¡t.
-- ============================================================================
PRINT N'----------------------------------------------------------------------------';
PRINT N'1. TRUY Váº¤N KHI CHÆ¯A CÃ“ COVERING INDEX (INDEX SEEK + KEY LOOKUP)';
PRINT N'----------------------------------------------------------------------------';

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- 1.1. Truy váº¥n tra cá»©u chi tiáº¿t cÃ´ng theo khoáº£ng thá»i gian cá»§a nhÃ¢n viÃªn 25
PRINT N'>>> [BEFORE - 1.1] Tra cá»©u chi tiáº¿t cháº¥m cÃ´ng nhÃ¢n viÃªn 25 (Key Lookup):';
SELECT MaNV, NgayChamCong, GioVao, GioRa, TrangThai
FROM #CHAMCONG_BENCHMARK WITH (INDEX(UQ_Bench_MaNV_Ngay))
WHERE MaNV = 25 AND NgayChamCong BETWEEN '2026-01-01' AND '2026-09-30';

-- 1.2. Truy váº¥n tá»•ng há»£p sá»‘ ngÃ y lÃ m vÃ  tá»•ng giá» lÃ m (mÃ´ phá»ng vw_TongHopChamCongThang)
PRINT N'>>> [BEFORE - 1.2] Tá»•ng há»£p cÃ´ng vÃ  giá» lÃ m nhÃ¢n viÃªn 25 (Key Lookup / Aggregate):';
SELECT
    MaNV,
    MONTH(NgayChamCong) AS Thang,
    YEAR(NgayChamCong)  AS Nam,
    COUNT(CASE WHEN TrangThai IN (N'CO_MAT', N'DI_TRE', N'VE_SOM') THEN 1 END) AS SoNgayDiLam,
    COUNT(CASE WHEN TrangThai = N'DI_TRE' THEN 1 END) AS SoLanDiTre,
    COUNT(CASE WHEN TrangThai = N'VE_SOM' THEN 1 END) AS SoLanVeSom,
    COUNT(CASE WHEN TrangThai = N'VANG' THEN 1 END) AS SoNgayVang,
    SUM(CASE
        WHEN GioRa IS NOT NULL AND GioRa > GioVao
        THEN DATEDIFF(MINUTE, GioVao, GioRa)
        ELSE 0
    END) / 60.0 AS TongSoGioLam
FROM #CHAMCONG_BENCHMARK WITH (INDEX(UQ_Bench_MaNV_Ngay))
WHERE MaNV = 25 AND NgayChamCong BETWEEN '2026-01-01' AND '2026-09-30'
GROUP BY MaNV, YEAR(NgayChamCong), MONTH(NgayChamCong);

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 4: Táº O COVERING INDEX TRÃŠN Báº¢NG Táº M THEO THIáº¾T Káº¾ IX_CHAMCONG_MaNV_Ngay
-- Bá»• sung INCLUDE (GioVao, GioRa, TrangThai) Ä‘á»ƒ bao phá»§ toÃ n bá»™ cÃ¢u truy váº¥n
-- ============================================================================
PRINT N'----------------------------------------------------------------------------';
PRINT N'2. Táº O NON-CLUSTERED COVERING INDEX: IX_Bench_CHAMCONG_MaNV_Ngay';
PRINT N'----------------------------------------------------------------------------';

CREATE NONCLUSTERED INDEX IX_Bench_CHAMCONG_MaNV_Ngay
ON #CHAMCONG_BENCHMARK (MaNV, NgayChamCong)
INCLUDE (GioVao, GioRa, TrangThai);

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 5: ÄO LÆ¯á»œNG SAU KHI CÃ“ COVERING INDEX (AFTER COVERING INDEX)
-- Ká»³ vá»ng: Index Seek 100% trÃªn IX_Bench_CHAMCONG_MaNV_Ngay, 0 Key Lookup,
-- sá»‘ Logical Reads giáº£m máº¡nh tÆ°Æ¡ng á»©ng sá»‘ trang lÃ¡ cá»§a Non-clustered Index.
-- ============================================================================
PRINT N'----------------------------------------------------------------------------';
PRINT N'3. TRUY Váº¤N KHI ÄÃƒ CÃ“ COVERING INDEX (PURE INDEX SEEK - ZERO KEY LOOKUP)';
PRINT N'----------------------------------------------------------------------------';

SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- 3.1. Truy váº¥n tra cá»©u chi tiáº¿t cÃ´ng theo khoáº£ng thá»i gian cá»§a nhÃ¢n viÃªn 25
PRINT N'>>> [AFTER - 3.1] Tra cá»©u chi tiáº¿t cháº¥m cÃ´ng nhÃ¢n viÃªn 25 (Covering Index Seek):';
SELECT MaNV, NgayChamCong, GioVao, GioRa, TrangThai
FROM #CHAMCONG_BENCHMARK WITH (INDEX(IX_Bench_CHAMCONG_MaNV_Ngay))
WHERE MaNV = 25 AND NgayChamCong BETWEEN '2026-01-01' AND '2026-09-30';

-- 3.2. Truy váº¥n tá»•ng há»£p sá»‘ ngÃ y lÃ m vÃ  tá»•ng giá» lÃ m (mÃ´ phá»ng vw_TongHopChamCongThang)
PRINT N'>>> [AFTER - 3.2] Tá»•ng há»£p cÃ´ng vÃ  giá» lÃ m nhÃ¢n viÃªn 25 (Covering Index Seek):';
SELECT
    MaNV,
    MONTH(NgayChamCong) AS Thang,
    YEAR(NgayChamCong)  AS Nam,
    COUNT(CASE WHEN TrangThai IN (N'CO_MAT', N'DI_TRE', N'VE_SOM') THEN 1 END) AS SoNgayDiLam,
    COUNT(CASE WHEN TrangThai = N'DI_TRE' THEN 1 END) AS SoLanDiTre,
    COUNT(CASE WHEN TrangThai = N'VE_SOM' THEN 1 END) AS SoLanVeSom,
    COUNT(CASE WHEN TrangThai = N'VANG' THEN 1 END) AS SoNgayVang,
    SUM(CASE
        WHEN GioRa IS NOT NULL AND GioRa > GioVao
        THEN DATEDIFF(MINUTE, GioVao, GioRa)
        ELSE 0
    END) / 60.0 AS TongSoGioLam
FROM #CHAMCONG_BENCHMARK WITH (INDEX(IX_Bench_CHAMCONG_MaNV_Ngay))
WHERE MaNV = 25 AND NgayChamCong BETWEEN '2026-01-01' AND '2026-09-30'
GROUP BY MaNV, YEAR(NgayChamCong), MONTH(NgayChamCong);

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 6: XÃC THá»°C THÃ”NG TIN METADATA Cá»¦A CHá»ˆ Má»¤C TRÃŠN Báº¢NG Sáº¢N XUáº¤T THáº¬T
-- ============================================================================
PRINT N'----------------------------------------------------------------------------';
PRINT N'4. KIá»‚M TRA METADATA CHá»ˆ Má»¤C TRÃŠN Báº¢NG CHÃNH THá»¨C dbo.CHAMCONG';
PRINT N'----------------------------------------------------------------------------';

SELECT
    i.name AS TenChiMuc,
    i.type_desc AS LoaiChiMuc,
    i.is_unique AS RBiDuyNhat,
    c.name AS TenCot,
    ic.key_ordinal AS ThuTuKhoa,
    ic.is_included_column AS CotInclude
FROM sys.indexes i
JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE i.object_id = OBJECT_ID(N'dbo.CHAMCONG')
  AND i.name IN (N'IX_CHAMCONG_MaNV_Ngay', N'UQ_CHAMCONG_MaNV_Ngay')
ORDER BY i.name, ic.is_included_column, ic.key_ordinal;

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- ============================================================================
-- BÆ¯á»šC 7: Dá»ŒN Dáº¸P Báº¢NG Táº M BENCHMARK (Äáº¢M Báº¢O KHÃ”NG áº¢NH HÆ¯á»žNG Dá»® LIá»†U THáº¬T)
-- ============================================================================
IF OBJECT_ID('tempdb..#CHAMCONG_BENCHMARK') IS NOT NULL
    DROP TABLE #CHAMCONG_BENCHMARK;

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

PRINT N'============================================================================';
PRINT N'  HOÃ€N Táº¤T Ká»ŠCH Báº¢N BENCHMARK INDEX IX_CHAMCONG_MaNV_Ngay Cá»¦A TV2.';
IF OBJECT_ID('tempdb..#CHAMCONG_BENCHMARK') IS NOT NULL THROW 53411,N'Benchmark cleanup failed.',1;
PRINT N'  ÄÃ£ dá»n báº£ng táº¡m benchmark.';
PRINT N'============================================================================';

GO

IF DB_NAME() <> N'PRJ_Fix_QA_20261013_001534_ae185d81'
    THROW 53410, N'Guard violation: Database context is not PRJ_Fix_QA_20261013_001534_ae185d81', 1;

-- METADATA EXPORT (CAST TO INT)
SELECT 
    i.name AS index_name,
    c.name AS column_name,
    ic.key_ordinal,
    CAST(ic.is_included_column AS INT) AS is_included_column
FROM sys.indexes i
JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE i.object_id = OBJECT_ID('dbo.CHAMCONG')
ORDER BY i.name, ic.key_ordinal, ic.index_column_id;

GO
