# TV2 — NGUỒN GỐC THỰC THI VÀ HƯỚNG DẪN TÁI LẬP THỦ CÔNG (PROVENANCE & REPRODUCTION V3)

- **Người lập:** Phạm Minh Quân (TV2 — MSSV: 24110311)
- **Ngày cập nhật:** 13/10/2026 (Hiệu chỉnh Loop 2 theo thẩm định Codex)
- **Database QA ủy quyền:** `localhost` / `PRJ_Fix_QA_20261013_001534_ae185d81`
- **Chính sách:** File này thay thế phiên bản v1, làm rõ trạng thái lưu trữ của harness lịch sử và cung cấp quy trình tái lập độc lập chuẩn mực qua SSMS.

---

## 1. Trạng Thái Của Script Tự Động Lịch Sử (`run_tv2_benchmark_final.ps1`)

File `reproduction/run_tv2_benchmark_final.ps1` là mã nguồn phục hồi từ ngữ cảnh thực thi của lượt chạy ngày 13/10/2026. File này được **lưu trữ để tham khảo lịch sử (ARCHIVE REFERENCE ONLY)**, **TUYỆT ĐỐI KHÔNG CHẠY LẠI** hoặc quảng bá việc gọi mặc định vì các lý do an toàn kỹ thuật sau:

1. **Nguy cơ ghi đè bằng chứng (Default Overwrite Risk):** Script gán giá trị mặc định `$RunId = "run_20261013_140800"`. Nếu thực thi mặc định, các lệnh `WriteAllLines` và `WriteAllText` sẽ ghi đè trực tiếp lên thư mục bằng chứng gốc đã được kiểm định.
2. **Cơ chế Guard phụ thuộc tham số:** Lệnh kiểm tra database so sánh `DB_NAME()` với biến tham số do người gọi truyền vào thay vì khóa cứng database QA ủy quyền cố định (`PRJ_Fix_QA_20261013_001534_ae185d81`).
3. **Lỗi xuất dữ liệu Boolean:** Script giữ nguyên cách xử lý cũ chuyển đổi `is_included_column` (kiểu BIT) thành chuỗi, dễ gây định dạng "True/False" thay vì giá trị số "1/0".
4. **Phụ thuộc đường dẫn tuyệt đối:** Script chứa các đường dẫn cục bộ tuyệt đối ổ đĩa `D:\` của tác giả ban đầu.

---

## 2. Quy Trình Tái Lập Độc Lập Chuẩn Mực Qua SSMS (Portable Manual SSMS Reproduction)

Để tái lập kết quả benchmark một cách độc lập, chuẩn xác và an toàn nhất, người thẩm định hoặc giảng viên nên thực hiện theo quy trình thủ công qua SQL Server Management Studio (SSMS):

### Bước 1: Chuẩn bị môi trường và Kết nối
- Mở **SQL Server Management Studio (SSMS)**.
- Kết nối tới máy chủ SQL Server cục bộ (`localhost`, `.` hoặc tên instance được ủy quyền) bằng tài khoản Windows Authentication (`-E`).
- Mở cửa sổ truy vấn mới (New Query) và chọn đúng database QA ủy quyền:
  ```sql
  USE PRJ_Fix_QA_20261013_001534_ae185d81;
  GO
  ```

### Bước 2: Bật chế độ thu thập Actual Execution Plan
- Trên thanh công cụ SSMS, bật tùy chọn **Include Actual Execution Plan** (phím tắt `Ctrl + M`).
- Tùy chọn này đảm bảo SQL Server xuất sinh cây kế hoạch thực tế đầy đủ kèm bộ đếm luồng `RunTimeCountersPerThread` cho từng toán tử.

### Bước 3: Thực thi kịch bản trên một phiên duy nhất (Single Session across GO)
- Mở file kịch bản SQL nguyên bản đã đóng gói:
  `Bo_nop_Nhom06/evidence/TV2/run_20261013_140800/test_benchmark_index_TV2.sql`
- **Quan trọng:** Chạy toàn bộ file trong **cùng một cửa sổ truy vấn duy nhất**. Mặc dù script có chứa các lệnh phân tách batch `GO`, kết nối của phiên (SPID) được duy trì liên tục để bảng tạm `#CHAMCONG_BENCHMARK` (30.000 dòng) không bị hủy giữa các bước đo.

### Bước 4: Lưu trữ kết quả sang thư mục mới tránh xung đột (Collision-Free Location)
- **Lưu Execution Plan:** Nhấp chuột phải vào từng tab Execution Plan tương ứng với 4 truy vấn và chọn **Save Execution Plan As...**:
  - `TV2_BEFORE_1_1.sqlplan` (Truy vấn chi tiết có Key Lookup)
  - `TV2_BEFORE_1_2.sqlplan` (Truy vấn aggregate có Key Lookup)
  - `TV2_AFTER_3_1.sqlplan` (Truy vấn chi tiết Pure Index Seek)
  - `TV2_AFTER_3_2.sqlplan` (Truy vấn aggregate Pure Index Seek)
  *Lưu ý: Luôn lưu vào thư mục mới (ví dụ: `build/evidence/TV2/run_manual_YYYYMMDD_HHMMSS/`), tuyệt đối không ghi đè thư mục `run_20261013_140800`.*
- **Lưu Messages:** Sao chép toàn bộ nội dung trong tab Messages (chứa thông tin `SET STATISTICS IO` và `SET STATISTICS TIME`) lưu thành file `TV2_benchmark_messages.log`.
- **Lưu dữ liệu kết quả:** Xuất kết quả 4 câu truy vấn ra file CSV để kiểm chứng tính đồng nhất 273 dòng (chi tiết) và 9 dòng (tổng hợp).

### Bước 5: Trích xuất Metadata chỉ mục bảng thật chuẩn xác
Chạy câu lệnh truy vấn sau với phép ép kiểu `CAST(... AS INT)` để lấy metadata chuẩn của chỉ mục `dbo.CHAMCONG`:
```sql
SELECT 
    i.name AS index_name,
    c.name AS column_name,
    ic.key_ordinal,
    CAST(ic.is_included_column AS INT) AS is_included_column
FROM sys.indexes i
JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE i.object_id = OBJECT_ID('dbo.CHAMCONG')
ORDER BY i.name, ic.key_ordinal, ic.index_column_id;
```

---

## 3. Công Bố Minh Bạch Về Các Lần Thu Thập Trước

Trước khi hoàn tất lượt chạy thành công `run_20261013_140800`, hệ thống đã thực hiện hai lượt thu thập sơ bộ:
- `run_20261013_135900`: Lượt chạy thiếu file actual plan XML hoàn chỉnh do script chưa kích hoạt bắt luồng XML của server.
- `run_20261013_140500`: Lượt chạy gặp sự cố ngắt lệnh do lỗi cú pháp trong việc tách các khối lệnh `GO`.

*Ghi chú minh bạch:* Các lần chạy trước được phân loại chính xác là **các lần thu thập siêu dữ liệu chưa hoàn chỉnh (incomplete metadata captures)**. Các giải trình chi tiết về nguyên nhân lỗi là nhận định từ phía executor trong quá trình xử lý, không phải là kết quả đo lường nguyên nhân gốc đã qua thẩm định độc lập. Nhóm cũng loại bỏ mọi tuyên bố chưa kiểm chứng cho rằng chuỗi kết nối `Server=(local)` chứng minh một giao thức mạng cụ thể hay có thể "loại bỏ hoàn toàn lỗi SSPI".
